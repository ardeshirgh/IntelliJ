package Ardeshir.ca;

    public class loop {
        static void loop (){
            System.out.println("test from loop method");


        }

        public static void main(String[] args) {
            
        }
    }

