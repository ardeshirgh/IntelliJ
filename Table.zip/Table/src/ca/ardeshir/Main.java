package ca.ardeshir;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


//        try {
//            Connection connection = DriverManager.getConnection("jdbc:sqlite:/Users/ardeshir.ghorbani/Documents/database/music.db");
//
//            Statement statement = connection.createStatement();
//            statement.execute("SELECT name FROM artists");
//            ResultSet results = statement.getResultSet();
//
//
//            while (results.next()){
//                System.out.println(results.getString("name"));
//            }
//
//        } catch (Exception e){
//            System.out.println(e.getMessage());
//        }






//        try(
//                Connection connection = DriverManager.getConnection("jdbc:sqlite:/Users/ardeshir.ghorbani/Documents/database/music.db");
//
//            Statement statement = connection.createStatement()) {
//
//            statement.execute("SELECT name FROM artists");
//            ResultSet results = statement.getResultSet();
//
//
//            while (results.next()){
//                System.out.println(results.getString("name"));
//            }
//
//        } catch (Exception e){
//            System.out.println(e.getMessage());
//        }

            Datasource ds = new Datasource();
//
     Scanner sn = new Scanner(System.in);
        System.out.println("name artist?: ");
        String name = sn.nextLine();
        List<Artist> artistList = new ArrayList<Artist>();
        if (ds.open()) {


            artistList = ds.queryForArtists(name);
            System.out.println("connected to db");
        } else{
            System.out.println("not connected to db");
        }


        if (artistList.isEmpty()){
            System.out.println("sorry there is no record for artist with that mean");
        }else{
            System.out.println("ARTIST IN MY DATABASE");
            System.out.println("id  ---  name");
        }
        for (Artist i : artistList){

            System.out.println(i.getId() + " ----- " + i.getName());
        }


        System.out.println("album name ?");
        String AlbumName = sn.nextLine();
        List<Albums> albumsList = new ArrayList<Albums>();
        if (ds.open()) {


            albumsList = ds.queryForAlbums(AlbumName);
            System.out.println("Connect");
        } else {
            System.out.println("not Connect");
            System.out.println("id  ----  name");

        }
        for (Albums i : albumsList){

            System.out.println(i.get_id() + "-----" + i.getName() + "-----" + i.getArtist());
        }
        System.out.println("song name ?");
        String songName = sn.nextLine();
        List<Songs> songList = new ArrayList<Songs>();
        if (ds.open()) {


            songList = ds.queryForSongs(songName);
            System.out.println("Connect");
        } else {
            System.out.println("not Connect");
            System.out.println("id  ----  name");

        }
        for (Songs i : songList){

            System.out.println(i.get_id() + "-----" + i.getTrack() + "-----" + i.getTitle() + "-----" + i.getAlbum());
        }

    }
}
