package ca.ardeshir;

public class Albums {
    private String name;
    private  int _id;
    private int artist;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public int getArtist() {
        return artist;
    }

    public void setArtist(int artist) {
        this.artist = artist;
    }

    public Albums(int _id, String name, int artist) {
        this.name = name;
        this._id = _id;
        this.artist = artist;
    }
}
