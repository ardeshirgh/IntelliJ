package ca.ardeshir;

public class Songs {
    private int _id;

    public Songs(int _id, int track, String title, int album) {
        this._id = _id;
        this.track = track;
        this.title = title;
        this.album = album;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public int getTrack() {
        return track;
    }

    public void setTrack(int track) {
        this.track = track;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getAlbum() {
        return album;
    }

    public void setAlbum(int album) {
        this.album = album;
    }

    private int track;
    private String title;
    private int album;
}
