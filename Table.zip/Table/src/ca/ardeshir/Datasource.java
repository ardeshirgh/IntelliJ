package ca.ardeshir;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Datasource {

    private Connection conn;
    private String connectionString = "jdbc:sqlite:/Users/ardeshir.ghorbani/Documents/database/music.db";

    public boolean open() {
        try {
            conn = DriverManager.getConnection(connectionString);
            return true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    public List<Artist> queryForArtists(String name) {

        List<Artist> artists = new ArrayList<Artist>();
        try {
//            Statement statement = conn.createStatement();
//            statement.execute("SELECT * FROM artists WHERE name ='" + name + "'");
//
//            ResultSet rs = statement.getResultSet();

            PreparedStatement ps = conn.prepareStatement("SELECT *FROM artists WHERE name = ?");
            ps.setString(1, name);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                artists.add(new Artist(rs.getInt("_id"),
                        rs.getString("name")));


            }
            return artists;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }


    }

    public List<Albums> queryForAlbums(String name) {

        List<Albums> albums = new ArrayList<Albums>();
        try {

            PreparedStatement ds = conn.prepareStatement("SELECT * FROM albums WHERE name = ?");
            ds.setString(1, name);

            ResultSet rs = ds.executeQuery();

            while (rs.next()) {

                albums.add(new Albums(rs.getInt("_id"),
                        rs.getString("name"),
                        rs.getInt("artist")));


            }
            return albums;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }


    public List<Songs> queryForSongs(String name) {

        List<Songs> songs = new ArrayList<Songs>();
        try {

            PreparedStatement ds = conn.prepareStatement("SELECT * FROM Songs WHERE title = ?");
            ds.setString(1, name);

            ResultSet rs = ds.executeQuery();

            while (rs.next()) {

                songs.add(new Songs(rs.getInt("_id"),
                        rs.getInt("track"),
                        rs.getString("title"),
                        rs.getInt("album")));
            }
            return songs;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
    }


}


